from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, DateField, DecimalField, SubmitField

class addPurchaseForm(FlaskForm):
    purchaseDate = DateField('Date of Purchase:')
    thcInMG = IntegerField('THC in MG:')
    cost = DecimalField('Purchase Price:')
    hardness = DecimalField('Difficulty Rating at time of Purchase:')
    submit = SubmitField('Add Purchase')

class updateDataForm(FlaskForm):
    startDate = DateField('Start Date for Update:')
    endDate = DateField('End Date for Update:')
    hardness = DecimalField('Adjusted Difficulty Rating for Date Range:')
    submit = SubmitField('Update')
