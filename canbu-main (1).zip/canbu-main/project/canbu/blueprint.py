from flask import Flask, Blueprint, render_template, redirect, url_for
from project import db
from project.models import purchase
from project.canbu.forms import addPurchaseForm
from project.functions import create_master_df, updateHistory, progressReport

canbu_bp = Blueprint('canbu',
                            __name__,
                            template_folder='templates/canbu')


@canbu_bp.route('/')
def index():
    master_df, master_df_flag = create_master_df()
    graphicJSON = progressReport(master_df, master_df_flag)

    return render_template('home.html', graphJSON=graphicJSON )

@canbu_bp.route('/add', methods = ['GET', 'POST'])
def add():
    form = addPurchaseForm()
    if form.validate_on_submit():
        purchaseDate = form.purchaseDate.data
        thcInMG = form.thcInMG.data
        cost = form.cost.data
        hardness = form.hardness.data
        weightedValue = None
        daysBetween = None
        returnRate = None
        calculated = False
        active = True
        modifiedDate = purchaseDate
        
        new_purchase = purchase(purchaseDate, thcInMG, cost, hardness, weightedValue, daysBetween, returnRate, calculated, active, modifiedDate)

        db.session.add(new_purchase)
        db.session.commit()

        # Update History File and refresh data for graphic
        counter = updateHistory(purchaseDate, purchaseDate)

        return redirect(url_for('canbu.index'))
    return render_template('add_purchase.html', form=form )

@canbu_bp.route('/edit', methods = ['GET', 'POST'])
def edit():
    
    return redirect(url_for('canbu.index'))
    pass

@canbu_bp.route('/adjust', methods = ['GET', 'POST'])
def adjust():
    return redirect(url_for('canbu.index'))
    pass

@canbu_bp.route('/support', methods = ['GET', 'POST'])
def support():
    return redirect(url_for('canbu.index'))
    pass

@canbu_bp.route('/about', methods = ['GET', 'POST'])
def about():
    return redirect(url_for('canbu.index'))
    pass
@canbu_bp.route('/contact', methods = ['GET', 'POST'])
def contact():
    return redirect(url_for('canbu.index'))
    pass





"""
@canbu_bp.route('/canbu_update', methods = ['GET', 'POST'])
def update():
    form = updateHistoryForm()
    if form.validate_on_submit():
        updateData = form.updateData.data
        updateStartDate = form.updateStartDate.data
        updateEndDate = form.updateEndDate.data
                
        if updateData:
            updateHistory(updateStartDate, updateEndDate)

        db.session.commit()

        # Update History File and refresh data for graphic
        
        return redirect(url_for('index'))
    return render_template('update_data.html', form = form )

def updateHistory(startDate, endDate):
    selection = select(purchase).where(purchase.purchaseDate >= startDate).where(purchase.purchaseDate <= endDate)
    with Session(engine) as session:
        df = pd.DataFrame(columns = ['purchaseDate', 'weightedValue', 'daysBetween', 'returnRate', 'active'])
        for row in session.execute(selection):
            purchaseDate = purchase.purchaseDate
            weightedValue = purchase.thcInMG * purchase.cost * (-1 * purchase.hardness)
            # Need to calculate the actual daysBetween
            daysBetween = 5
            # also need to calculate the proper return rate
            returnRate = weightedValue + daysBetween + history[-1].returnRate
            active = True
            df.append[purchaseDate, weightedValue, daysBetween, returnRate, active]
        df.to_sql(history, if_exists='Append')
"""